jQuery(function ($) {
    "user strict";
    $(".redux-container-pxl_iconpicker .pxl-iconpicker").fontIconPicker();
});