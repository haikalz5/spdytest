<?php
    echo 'this is the example widget layout 2';
?>