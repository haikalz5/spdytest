<?php
$uri = get_template_directory_uri() . '/inc/admin/demo-data/demo-imgs/';
// Demos
$demos = array(
	// Elementor Demos
	'loraic' => array(
		'title'       => 'Loraic',	
		'description' => '',
		'screenshot'  => $uri . 'screenshot.jpg',
		'preview'     => 'https://demo.bravisthemes.com/loraic/',
	),
); 