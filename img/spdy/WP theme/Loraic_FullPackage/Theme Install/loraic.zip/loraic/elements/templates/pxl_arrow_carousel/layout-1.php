<div class="pxl-navigation-carousel <?php echo esc_attr($settings['style']); ?>">
    <div class="pxl-navigation-arrow pxl-navigation-arrow-prev">
        <svg xmlns="http://www.w3.org/2000/svg" width="11" height="18" viewBox="0 0 11 18" fill="none">
            <path d="M9.61523 0.923096L1.53831 9.00002L9.61523 16.5" stroke="white" stroke-width="1.5"/>
        </svg>
    </div>
    <div class="pxl-navigation-arrow pxl-navigation-arrow-next">
        <svg xmlns="http://www.w3.org/2000/svg" width="11" height="18" viewBox="0 0 11 18" fill="none">
            <path d="M1 0.923096L9.07692 9.00002L1 16.5" stroke="white" stroke-width="1.5"/>
        </svg>
    </div>
</div>