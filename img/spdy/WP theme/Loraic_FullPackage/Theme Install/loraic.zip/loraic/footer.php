<?php
/**
 * @package Bravis-Themes
 */
?>
		</div><!-- #main -->

		<?php loraic()->footer->getFooter(); ?>
		<?php do_action( 'pxl_anchor_target') ?>
		</div><!-- #wapper -->
	<?php wp_footer(); ?>
	</body>
</html>
