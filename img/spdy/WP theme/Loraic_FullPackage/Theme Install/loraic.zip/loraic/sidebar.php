<?php
/**
 * @package Bravis-Themes
 */

dynamic_sidebar( loraic()->get_sidebar() );